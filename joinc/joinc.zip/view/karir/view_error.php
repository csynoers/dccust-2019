<div class="alert alert-info">
  <strong>Info!</strong> Maaf Data Belum Ada.
</div>