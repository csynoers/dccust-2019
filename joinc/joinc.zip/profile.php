<!-- end header -->
	<section id="featured">
	<!-- start slider -->
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
	<!-- Slider -->
        <div id="main-slider" class="flexslider">
            <ul class="slides">
			<?php
				$statik=mysql_query("SELECT * FROM profile where id_profile='9'");
				$statis=mysql_fetch_array($statik);
				// $nama	 	= $_SESSION['bahasa'] 	== "en" ? "nama_profile_".$_SESSION[bahasa] : "nama_profile_ina";
				// $isi	 	= $_SESSION['bahasa'] 	== "en" ? "isi_profile_".$_SESSION[bahasa] : "isi_profile_ina";
				// $visi	 	= $_SESSION['bahasa'] 	== "en" ? "visi_profile_".$_SESSION[bahasa] : "visi_profile_ina";
				// $misi	 	= $_SESSION['bahasa'] 	== "en" ? "misi_profile_".$_SESSION[bahasa] : "misi_profile_ina";
				// $nilai	 	= $_SESSION['bahasa'] 	== "en" ? "nilai_profile_".$_SESSION[bahasa] : "nilai_profile_ina";
				// $struktur	= $_SESSION['bahasa'] 	== "en" ? "struktur_profile_".$_SESSION[bahasa] : "struktur_profile_ina";
			?>
              <li>
                <img width="100%" src="joimg/profile/<?php echo "$statis[gambar]" ?>" alt="" />
                <div class="flex-caption">
                    <h3><?php echo "$statis[nama_profile_ina]";?></h3> 
                </div>
              </li>
            </ul>
        </div>
	<!-- end slider -->
			</div>
		</div>
	</div>	
	</section>
	<section id="featured">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-9">
			<div class="col-lg-12 col-md-12">
				<div class="bawah">
					<center><h5><span style="color: #009a54;   font-size: 26px;" data-mce-mark="1">Profile</span></h3></center>
				</div>
					<?php echo "$statis[isi_profile_ina]";?>
				</div>
			</div>
			
			<div class="col-lg-3 col-md-3">
				<aside class="right-sidebar">
					<div class="thum">
						<div style="margin-left:10px;">
							<h5 class="widgetheading">Search DCC UST</h5>
							<form class="form-search">
								<input class="form-control" style="  margin-top: -19px; margin-bottom: 9px;" type="text" placeholder="Search..">
								<!--<input class="art-search-button" type="submit" value="Search" />-->
							</form>
						</div>
					</div>
					<div class="thum">
						<div style="margin-left:10px;">
							<h5 class="widgetheading">Visi</h5>
							<?php echo "$statis[visi_profile_ina]";?>
						</div>
					</div>
					<div class="thum">
						<div style="margin-left:10px;">
							<h5 class="widgetheading">Misi</h5>
							<?php echo "$statis[misi_profile_ina]";?>
						</div>
					</div>
					
				</aside>
			</div>
			
		</div>
	</div>
	</section>