<?php
	$id_page= $_POST['id_page'];
	echo "$id_page";