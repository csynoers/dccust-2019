<div class="alert alert-warning alert-dismissable">
	Terimaksih telah berpartisipasi mengisi kuesioner.<br>
	Klik <a class="alert-link" href="home-dccustjogja.html"><b>Kembali ke Home</b></a> Apabila anda belum menerima email dari kami.
</div>