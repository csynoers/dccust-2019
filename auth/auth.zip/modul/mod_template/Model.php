<?php
    class Model extends dbHelper
    {
        public function get_data()
        {

        }

        public function store_data()
        {

        }

        public function delete_data()
        {
            
        }
    }
    