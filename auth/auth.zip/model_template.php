<?php
    class Model_ extends dbHelper
    {
        public function __construct($db_config){
			parent::__construct($db_config);
		}
    }
    